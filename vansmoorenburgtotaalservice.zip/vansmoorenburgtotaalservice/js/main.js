// ─── Smooth scroll for nav links ───
document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    const target = document.querySelector(link.getAttribute('href'));
    if (target) target.scrollIntoView({ behavior: 'smooth' });
  });
});

// ─── Formspree contact form ───
// Vervang YOUR_FORM_ID met jouw Formspree endpoint ID
// Maak een gratis account aan op https://formspree.io
// Klik op "+ New Form", kopieer het endpoint, en vervang hieronder
const FORMSPREE_ENDPOINT = 'https://formspree.io/f/YOUR_FORM_ID';

const form = document.getElementById('contact-form');
const formSuccess = document.getElementById('form-success');

if (form) {
  form.addEventListener('submit', async e => {
    e.preventDefault();

    const btn = form.querySelector('.form-submit');
    btn.textContent = 'Versturen...';
    btn.disabled = true;

    const data = new FormData(form);

    try {
      const res = await fetch(FORMSPREE_ENDPOINT, {
        method: 'POST',
        body: data,
        headers: { Accept: 'application/json' }
      });

      if (res.ok) {
        form.style.display = 'none';
        formSuccess.style.display = 'block';
      } else {
        btn.textContent = 'Verstuur aanvraag';
        btn.disabled = false;
        alert('Er ging iets mis. Probeer het opnieuw of bel ons direct.');
      }
    } catch {
      btn.textContent = 'Verstuur aanvraag';
      btn.disabled = false;
      alert('Er ging iets mis. Controleer je internetverbinding.');
    }
  });
}
